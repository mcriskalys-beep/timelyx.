
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const app = express();
const port = 3000;

app.use(express.json());

app.post('/create-checkout-session', async (req, res) => {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'eur',
          product_data: {
            name: 'Timelyx Life Time',
          },
          recurring: { interval: 'year' },
          unit_amount: 79000, // 79,00 € in cents
        },
        quantity: 1,
      },
      {
        price_data: {
          currency: 'eur',
          product_data: { name: 'Timelyx Pro' },
          recurring: { interval: 'month' },
          unit_amount: 2999, // 29,99 €
        },
        quantity: 1,
      },
      {
        price_data: {
          currency: 'eur',
          product_data: { name: 'Timelyx Basic' },
          recurring: { interval: 'month' },
          unit_amount: 999, // 9,99 €
        },
        quantity: 1,
      },
    ],
    mode: 'subscription',
    success_url: `${process.env.YOUR_DOMAIN}/success`,
    cancel_url: `${process.env.YOUR_DOMAIN}/cancel`,
  });

  res.redirect(303, session.url);
});

app.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    console.log('Payment was successful!', session);
  }

  res.json({ received: true });
});

app.listen(port, () => console.log(`Server running on port ${port}`));
    