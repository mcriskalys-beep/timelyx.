
import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center' }}>
      <h1>Choisissez votre abonnement Timelyx</h1>
      <div style={{ margin: '20px' }}>
        <a href="https://buy.stripe.com/bJeaEW1B32qS0w95DG2Ji04" target="_blank" rel="noopener noreferrer">
          <button style={{ padding: '15px 30px', fontSize: '18px' }}>Timelyx Life Time — 79,00 € / an</button>
        </a>
      </div>
      <div style={{ margin: '20px' }}>
        <a href="https://buy.stripe.com/bJecN4a7zfdE1Adc242Ji07" target="_blank" rel="noopener noreferrer">
          <button style={{ padding: '15px 30px', fontSize: '18px' }}>Timelyx Pro — 29,99 € / mois</button>
        </a>
      </div>
      <div style={{ margin: '20px' }}>
        <a href="https://buy.stripe.com/9B628qenP9Tk2Ehd682Ji06" target="_blank" rel="noopener noreferrer">
          <button style={{ padding: '15px 30px', fontSize: '18px' }}>Timelyx Basic — 9,99 € / mois</button>
        </a>
      </div>
    </div>
  );
}

export default App;
    